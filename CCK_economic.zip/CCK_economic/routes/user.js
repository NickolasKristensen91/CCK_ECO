const passwordHash = require('password-hash');

module.exports = function (app) {

    // route til at render login side

    app.get('/login', function (req, res) {
        res.render('pages/login');
    });


    // ================================================================

    // route til at logge ind med

    app.post('/login', function (req, res) {
        var message;
        var post = req.body;
        var name = post.user_name;

        db.query(`SELECT id, user_name, rolle, password FROM users WHERE user_name = ?`, [name], (err, results) => {
            if (err) {
                console.log("Fejl i logging ind: " + err)
                return;
            }
            if (results[0] != null) {
                if (passwordHash.verify(post.password, results[0].password)) {
                    req.session.userId = results[0].id;
                    req.session.user = results[0];
                    req.session.userRole = results[0].rolle;


                    if (results[0].rolle == 'admin') {
                        res.redirect('/admin/dashboard')
                    } else if (results[0].rolle == 'instruktoer') {
                        res.redirect('/instruktoer_dashboard')
                    } else if (results[0].rolle == 'medlem') {
                        res.redirect('/minside')
                    } else {
                        message = 'fejl i login, kontakt support!';
                        res.render('pages/login', {
                            message: message
                        });
                    }


                } else {
                    message = 'Indtastede oplysninger er ikke korrekt!';
                    res.render('pages/login', {
                        message: message
                    });
                }
            } else {
                message = 'Indtastede brugernavn og adgangskode er ikke korrekt!';
                res.render('pages/login', {
                    message: message
                });
            }
        });
    });



    // ================================================================

    // route til at logge ud
    app.get('/logout', function (req, res) {
        req.session.destroy(function (err) {
            res.redirect("/login");
        });
    });


    // ================================================================

    // route til at render signup siden
    app.get('/signup', function (req, res) {
        res.render('pages/signup');
    });


    // ================================================================

    // route til at oprette bruger
    app.post('/signup', function (req, res) {
        var message = '';
        var post = req.body;
        var name = post.user_name;

        var password = passwordHash.generate(post.password);
        // var pass = post.password;

        var fname = post.first_name;
        var lname = post.last_name;
        var mob = post.mob_no;

        // TODO: Tilføj validering af resten af de indtastede oplysninger!

        if (name != "" && password != "") {

            var sql = `
                    INSERT INTO users
                    SET
                        first_name = 0,
                        last_name = 0,
                        mob_no = 0,
                        rolle = 'admin',
                        user_name = ?,
                        password = ?
                    `;

            db.query(sql, [name, password], function (err, result) {
                if (err) {
                    console.log("signup error: " + err);
                } else {
                    message = "Succesfully! Your account has been created.";
                    res.render('pages/signup', {
                        message: message,
                        messageType: "alert-success",
                        showForm: false
                    });
                }

            });
        } else {
            message = "Username and password are required!";
            res.render('pages/signup', {
                message: message,
                messageType: "alert-danger"
            });
        }
    });


    // ================================================================




    // ================================================================

    // route til at render profil siden
    app.get('/profile', function (req, res) {
        var userRole = req.session.userRole
        var userId = req.session.userId;
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        }

        // henter alt data fra databasen omkring brugeren (Bruges ikke)
        var sql = "SELECT * FROM users WHERE id = ?";
        db.query(sql, [userId], function (err, result) {
            res.render('pages/profile', {
                data: result
            });
        });
    });


    // ================================================================


} // End of: module.exports