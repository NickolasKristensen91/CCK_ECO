// :: ROUTES samlingspunkt til server

module.exports = function (app) {
    // Hjemmeside:
    require("./index")(app);
    require("./sitets_sider")(app);
    // Admin:
    // require("./user")(app);
    // require("./dashboard")(app);
    // require("./admin_brugere")(app);
    // require("./admin_nyhedsbrev")(app);
    // require("./admin_arrangementer")(app);

    // Medlem:
    // require("./medlem")(app);

    // // Instruktør:
    // require("./instruktoer")(app);
};