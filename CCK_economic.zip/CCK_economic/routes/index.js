// :: ROUTES TIL index siden

module.exports = (app) => {
    // route til at render index side
    app.get('/', function (req, res) {
        db.query(function (err) {
            res.render('pages/index', {});
        });
    });

    // app.get('/sogeresultat/:search', function (req, res) {
    //     var search = req.params.search;
    //     db.query(`select * from arrangementer where navn like '%${search}%'`, (err, search) => {
    //         res.render('pages/sogeresultat', {
    //             search: search
    //         })
    //     })
    // })


}