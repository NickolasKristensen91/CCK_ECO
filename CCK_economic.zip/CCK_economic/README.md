node-ejs
========

Using EJS to template a Node application.
