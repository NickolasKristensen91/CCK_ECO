-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Vært: 127.0.0.1
-- Genereringstid: 05. 09 2018 kl. 15:10:04
-- Serverversion: 5.6.24
-- PHP-version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kajakklubben`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `arrangementer`
--

CREATE TABLE IF NOT EXISTS `arrangementer` (
  `id` int(11) NOT NULL,
  `navn` varchar(30) NOT NULL,
  `dato` date NOT NULL,
  `tekst` varchar(500) NOT NULL,
  `billede` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `arrangementer`
--

INSERT INTO `arrangementer` (`id`, `navn`, `dato`, `tekst`, `billede`) VALUES
(1, 'Sommerafslutning', '2020-06-30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'kajak04.jpg'),
(2, 'Familiesejlads i sommerferien', '2020-07-09', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'kajak05.jpg'),
(3, 'fffffffff123', '0000-00-00', '                        wewewewewewewe\n        \n        ', 'kajak19.jpg');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `baadpark`
--

CREATE TABLE IF NOT EXISTS `baadpark` (
  `id` int(11) NOT NULL,
  `fk_kategori` int(11) NOT NULL,
  `svaerhedsgrad` int(6) NOT NULL,
  `antal` int(6) NOT NULL,
  `tekst` varchar(200) NOT NULL,
  `billede` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `baadpark`
--

INSERT INTO `baadpark` (`id`, `fk_kategori`, `svaerhedsgrad`, `antal`, `tekst`, `billede`) VALUES
(1, 1, 0, 2, 'Hasle Explorer med finne (K1)', 'kajak20.jpg'),
(2, 1, 0, 1, 'Hasle Explorer med ror (K1)', 'kajak21.jpg'),
(3, 2, 11, 1, 'Seabird (K1)', 'kajak22.jpg'),
(4, 2, 11, 2, 'Malik (K1)', 'kajak23.jpg'),
(5, 2, 11, 1, 'Coastline (K1)', 'kajak24.jpg'),
(6, 3, 7, 2, 'Tracer (K1)', 'kajak25.jpg'),
(7, 3, 1, 1, 'Mosquito (K1)', 'kajak26.jpg'),
(8, 3, 1, 2, 'Struer trækajakker (K2) – Pt. ude af drift', 'kajak27.jpg'),
(9, 1, 11, 21, 'SUPERKAJAKKEN', 'kajak02.jpg'),
(10, 3, 11, 5, 'EXPERT NIV GAMMA\n        ', 'kajak02.jpg');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `baadtype_kategori`
--

CREATE TABLE IF NOT EXISTS `baadtype_kategori` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `baadtype_kategori`
--

INSERT INTO `baadtype_kategori` (`id`, `type`) VALUES
(1, 'Havkajak'),
(2, 'Turkajak'),
(3, 'Kapkajak');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `galleri`
--

CREATE TABLE IF NOT EXISTS `galleri` (
  `id` int(11) NOT NULL,
  `navn` varchar(20) NOT NULL,
  `fk_kategori` int(11) NOT NULL,
  `billeder` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `galleri`
--

INSERT INTO `galleri` (`id`, `navn`, `fk_kategori`, `billeder`) VALUES
(1, 'Tur i det kolde', 1, 'kajak06.jpg'),
(2, 'Langrand', 2, 'kajak06.jpg');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `galleri_kategori`
--

CREATE TABLE IF NOT EXISTS `galleri_kategori` (
  `id` int(11) NOT NULL,
  `kategori_navn` varchar(20) NOT NULL,
  `billede` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `galleri_kategori`
--

INSERT INTO `galleri_kategori` (`id`, `kategori_navn`, `billede`) VALUES
(1, 'Tur i det kolde', 'kajak06.jpg'),
(2, 'Langrand', 'kajak07.jpg'),
(3, 'Sejl frit', 'kajak08.jpg'),
(5, 'Strandhygge', 'kajak09.jpg'),
(6, 'Den tidlige tur', 'kajak10.jpg'),
(7, 'Brugte kajakker', 'kajak11.jpg'),
(8, 'Udforsk vandet', 'kajak12.jpg'),
(9, 'Riverrafting', 'kajak13.jpg'),
(10, 'Nyt sortiment', 'kajak14.jpg'),
(11, 'Sandåen', 'kajak15.jpg'),
(12, 'Havet er skønt', 'kajak16.jpg'),
(13, 'Familie sejlads', 'kajak17.jpg');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `kontakt_besked`
--

CREATE TABLE IF NOT EXISTS `kontakt_besked` (
  `id` int(11) NOT NULL,
  `navn` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefonnr` int(8) NOT NULL,
  `besked` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `kontakt_besked`
--

INSERT INTO `kontakt_besked` (`id`, `navn`, `email`, `telefonnr`, `besked`) VALUES
(1, 'Nickolas Kristensen', 'sfbysdvf@dfmidn.dk', 34567890, 'sdsd');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `nyheder`
--

CREATE TABLE IF NOT EXISTS `nyheder` (
  `id` int(11) NOT NULL,
  `navn` varchar(20) NOT NULL,
  `dato` date NOT NULL,
  `tekst` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `nyheder`
--

INSERT INTO `nyheder` (`id`, `navn`, `dato`, `tekst`) VALUES
(1, 'Lorem_et', '2018-09-14', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(2, 'Lorem_to', '2018-09-20', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `nyhedsbrev`
--

CREATE TABLE IF NOT EXISTS `nyhedsbrev` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `nyhedsbrev`
--

INSERT INTO `nyhedsbrev` (`id`, `email`) VALUES
(1, 'dsdsd'),
(2, 'dsdsd'),
(3, 'dsdsdssd'),
(4, 'sds'),
(5, 'sds'),
(6, 'cdscs');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(5) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `mob_no` int(11) NOT NULL,
  `rolle` varchar(25) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `mob_no`, `rolle`, `user_name`, `password`) VALUES
(13, '', '', 0, 'medlem', 'medlem1234', 'sha1$05c013cb$1$c9b01184193432c6ba5f97742c020bbfd3f1ef61'),
(14, '', '', 0, 'instruktoer', 'instruktør1234', 'sha1$84efb5ca$1$62873b11b978cdd89959d0653c56b51ee404b635'),
(16, '0', '0', 0, 'admin', 'admin1234', 'sha1$b4176b4b$1$55f26af4bea583645dad4906bc43750b5910363a');

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `arrangementer`
--
ALTER TABLE `arrangementer`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `baadpark`
--
ALTER TABLE `baadpark`
  ADD PRIMARY KEY (`id`), ADD KEY `fk_kategori` (`fk_kategori`);

--
-- Indeks for tabel `baadtype_kategori`
--
ALTER TABLE `baadtype_kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `galleri`
--
ALTER TABLE `galleri`
  ADD PRIMARY KEY (`id`), ADD KEY `fk_kategori` (`fk_kategori`), ADD KEY `fk_kategori_2` (`fk_kategori`);

--
-- Indeks for tabel `galleri_kategori`
--
ALTER TABLE `galleri_kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `kontakt_besked`
--
ALTER TABLE `kontakt_besked`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `nyheder`
--
ALTER TABLE `nyheder`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `nyhedsbrev`
--
ALTER TABLE `nyhedsbrev`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `arrangementer`
--
ALTER TABLE `arrangementer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Tilføj AUTO_INCREMENT i tabel `baadpark`
--
ALTER TABLE `baadpark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- Tilføj AUTO_INCREMENT i tabel `baadtype_kategori`
--
ALTER TABLE `baadtype_kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Tilføj AUTO_INCREMENT i tabel `galleri`
--
ALTER TABLE `galleri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Tilføj AUTO_INCREMENT i tabel `galleri_kategori`
--
ALTER TABLE `galleri_kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- Tilføj AUTO_INCREMENT i tabel `kontakt_besked`
--
ALTER TABLE `kontakt_besked`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Tilføj AUTO_INCREMENT i tabel `nyheder`
--
ALTER TABLE `nyheder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Tilføj AUTO_INCREMENT i tabel `nyhedsbrev`
--
ALTER TABLE `nyhedsbrev`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- Tilføj AUTO_INCREMENT i tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `baadpark`
--
ALTER TABLE `baadpark`
ADD CONSTRAINT `baadpark_ibfk_1` FOREIGN KEY (`fk_kategori`) REFERENCES `baadtype_kategori` (`id`);

--
-- Begrænsninger for tabel `galleri`
--
ALTER TABLE `galleri`
ADD CONSTRAINT `galleri_ibfk_1` FOREIGN KEY (`fk_kategori`) REFERENCES `galleri_kategori` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
