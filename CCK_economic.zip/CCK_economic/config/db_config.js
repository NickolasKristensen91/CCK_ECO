// Opretter forbindelsen til databasen: kajakklubben

const mysql = require('mysql');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'kajakklubben'
});

connection.connect();

global.db = connection;